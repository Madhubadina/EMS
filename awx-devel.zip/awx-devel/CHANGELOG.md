# Changelog

**Note:** This file is deprecated and will be removed at some point in a future release.

Starting with AWX 20, release notes are published to [GitHub Releases](https://github.com/ansible/awx/releases).

For older release notes, see https://github.com/ansible/awx/blob/19.3.0/CHANGELOG.md.
