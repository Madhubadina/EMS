
POST requests to this resource must include a proper `rrule` value following
a particular format and conforming to subset of allowed rules.

{% include "api/_schedule_detail.md" %}
